#include <iostream>
#include "Display.h"

using namespace std;

void printGrid(QRCode& qr) {

    vector<string>& grid = qr.getGrid();

    for (string row : grid) {

        for (char cell : row) {

            // filled QR cell
            if (cell == '#')
                cout << "██";

            // empty data cell
            else if (cell == '.')
                cout << "  ";

            // my signature cell
            else if (cell == '@')
                cout << "<>";

            // normal blank space
            else
                cout << "  ";
        }

        cout << endl;
    }
}

void explainSignature() {

    cout << "The <> diagonal pattern is the creator signature." << endl;
}

void menu() {

    cout << "1. Encode" << endl;
    cout << "2. Decode" << endl;
    cout << "3. Exit" << endl;
}
