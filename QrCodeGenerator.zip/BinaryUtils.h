#ifndef BINARYUTILS_H
#define BINARYUTILS_H

#include <string>

using namespace std;

// Converts full text to binary and binary back to text.
string textToBinary(const string& text);
string binaryToText(const string& binary);

// Converts one character to binary and 8 binary bits back to one character.
string charToBinary(char c);
char binaryToChar(const string& bits);

// Checksum helpers used for data integrity checks.
int calculateChecksum(const string& text);
string intTo8BitBinary(int value);
string intTo16BitBinary(int value);
int binaryToInt(const string& bits);

// Creates the full data that is stored in the QR grid.
// Format: [16 bits length][message bits][8 bits checksum]
string createEncodedBinary(const string& text);

// Decodes the QR data and returns true only if the checksum matches.
bool decodeEncodedBinary(const string& binary, string& decodedText);

#endif
