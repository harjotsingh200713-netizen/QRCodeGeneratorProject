#include <iostream>
#include <string>
#include <limits>   // for numeric_limits, used to clear bad menu input
#include <fstream>  // for file checking stuff

#include "QRCode.h"
#include "BinaryUtils.h"
#include "FileUtils.h"
#include "Checksum.h"
#include "Display.h"

using namespace std;

int main() {

    // just the title at the top so it looks nicer when it starts
    cout << "========================================\n";
    cout << "          QR CODE GENERATOR\n";
    cout << "========================================\n";

    int choice = 0;

    // keeps running until the user picks 3
    while (true) {

        cout << endl;
        menu();

        cin >> choice;

        // if someone types letters instead of a number, cin breaks
        // so this resets it and throws away the bad input
        // citation kinda: cppreference says numeric_limits gives the max value for a type,
        // so max() here is just a huge number to clear the whole line.
        // Source: cppreference, std::numeric_limits and numeric_limits::max
        if (cin.fail()) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');

            cout << "\nInvalid input. Please enter a number.\n";
            continue;
        }

        // gets rid of the leftover enter key so getline doesn't read nothing
        // Source: cppreference, std::basic_istream::ignore
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        if (choice == 1) {

            // making the QR bigger so longer messages do not get cut off as fast
            QRCode qr(35);

            // set up the blank grid and the fake QR corner patterns/signature
            initializeGrid(qr);
            addFinderPatterns(qr);
            addSignature(qr);

            string message;

            cout << "\nEnter message to encode: ";
            getline(cin, message);

            // this makes the real data that goes into the grid
            // format is length first, then message, then checksum
            string binary = createEncodedBinary(message);

            // puts the 1s and 0s into the grid as # and .
            bool encoded = encodeBinaryToGrid(qr, binary);

            // if the message was too long, don't keep going with a broken QR
            if (!encoded) {
                cout << "\nQR code was not created. Nothing was saved.\n";
                continue;
            }

            cout << endl;
            printGrid(qr);

            cout << endl;
            explainSignature();

            // decode it right away to make sure it actually worked
            string decodedBinary = decodeGridToBinary(qr);
            string decodedText;

            // this checks the checksum that got stored inside the QR data
            bool checksumPassed = decodeEncodedBinary(decodedBinary, decodedText);

            if (checksumPassed) {
                cout << "\nChecksum PASSED - data integrity verified!\n";
            }
            else {
                cout << "\nChecksum FAILED - data may be corrupted!\n";
            }

            char saveChoice;

            cout << "\nSave QR to file? (y/n): ";
            cin >> saveChoice;
            cin.ignore(numeric_limits<streamsize>::max(), '\n');

            if (saveChoice == 'y' || saveChoice == 'Y') {

                // don't save it if it already failed the check
                if (!checksumPassed) {
                    cout << "\nError: QR code was not saved because the data is corrupted.\n";
                    cout << "Please try encoding the message again.\n";
                }
                else {
                    string filename;

                    cout << "\nEnter filename: ";
                    getline(cin, filename);

                    // saveToFile says true if it worked
                    if (saveToFile(qr, filename)) {
                        cout << "\nQR code saved successfully.\n";
                    }
                }
            }
        }

        else if (choice == 2) {

            // saved files are 35 by 35 now, so decode with the same size
            QRCode qr(35);

            string filename;

            cout << "\nEnter filename to decode: ";
            getline(cin, filename);

            // loadFromFile returns false if the file is missing or messed up
            if (!loadFromFile(qr, filename)) {
                cout << "No message was decoded.\n";
                continue;
            }

            // turns # and . back into 1s and 0s
            string binary = decodeGridToBinary(qr);

            if (binary.length() == 0) {
                cout << "\nError: No QR data was found in the file.\n";
                cout << "The file may be empty, corrupted, or invalid.\n";
                cout << "No message was decoded.\n";
                continue;
            }

            string text;

            // this uses the length and checksum that were stored in the QR
            bool success = decodeEncodedBinary(binary, text);

            if (!success) {
                cout << "\nError: The QR data failed the checksum test.\n";
                cout << "The file may be corrupted or invalid.\n";
                cout << "No message was decoded.\n";
                continue;
            }

            if (text.length() == 0) {
                cout << "\nError: Decoded message is empty.\n";
                cout << "The file may be corrupted or invalid.\n";
                cout << "No message was decoded.\n";
                continue;
            }

            cout << "\nDecoded message:\n";
            cout << text << endl;

            cout << "\nChecksum: " << checksum(text) << endl;
        }

        else if (choice == 3) {

            cout << "\nProgram ended.\n";
            break;
        }

        else {

            cout << "\nInvalid choice. Please choose 1, 2, or 3.\n";
        }
    }

    return 0;
}
