#include <fstream>
#include <iostream>
#include "FileUtils.h"

using namespace std;

bool saveToFile(QRCode& qr, const string& filename) {

    // ofstream writes to files
    // Source: cppreference, std::basic_ofstream / file output stream
    ofstream outFile(filename);

    if (!outFile) {
        cout << "\nError: Could not open file for saving.\n";
        return false;
    }

    vector<string>& grid = qr.getGrid();

    // save every row of the grid as a line in the text file
    for (string row : grid) {
        outFile << row << endl;
    }

    outFile.close();
    return true;
}

bool loadFromFile(QRCode& qr, const string& filename) {

    // ifstream reads from files
    // Source: cppreference, std::basic_ifstream / file input stream
    ifstream inFile(filename);

    if (!inFile) {
        cout << "\nError: File could not be found or opened.\n";
        return false;
    }

    vector<string>& grid = qr.getGrid();

    // read one file line for every row in the QR grid
    for (int i = 0; i < qr.getSize(); i++) {

        if (!getline(inFile, grid[i])) {
            cout << "\nError: File is missing QR grid rows.\n";
            return false;
        }

        // if the row is too short, the file is probably not a good QR file
        if (grid[i].length() < static_cast<unsigned int>(qr.getSize())) {
            cout << "\nError: QR file row " << i + 1 << " is too short.\n";
            cout << "The file may be corrupted or invalid.\n";
            return false;
        }

        // if the row is too long, only keep the actual grid part
        if (grid[i].length() > static_cast<unsigned int>(qr.getSize())) {
            grid[i] = grid[i].substr(0, qr.getSize());
        }
    }

    inFile.close();
    return true;
}
