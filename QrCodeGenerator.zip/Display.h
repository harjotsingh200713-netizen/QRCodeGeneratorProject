#ifndef DISPLAY_H
#define DISPLAY_H

#include "QRCode.h"

// Prints the QR grid in a more visual way.
void printGrid(QRCode& qr);

// Explains the creator signature shown in the QR code.
void explainSignature();

// Prints the main menu options.
void menu();

#endif
