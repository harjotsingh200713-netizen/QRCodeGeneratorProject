#ifndef FILEUTILS_H
#define FILEUTILS_H

#include <string>
#include "QRCode.h"

using namespace std;

// Saves the QR grid to a text file.
// Returns true if saving worked and false if it failed.
bool saveToFile(QRCode& qr, const string& filename);

// Loads the QR grid from a text file.
// Returns true if loading worked and false if the file was invalid.
bool loadFromFile(QRCode& qr, const string& filename);

#endif
