#ifndef QRCODE_H
#define QRCODE_H

#include <vector>
#include <string>

using namespace std;

// This class stores the custom QR code grid.
// The grid is a vector of strings, where each string is one row.
class QRCode {

private:
    vector<string> grid;  // Stores the actual QR symbols.
    int size;             // Number of rows and columns in the square grid.

public:
    // Creates a QRCode with a default size of 35 by 35.
    QRCode(int s = 35);

    // Gives other files access to the grid so they can edit or read it.
    vector<string>& getGrid();

    // Returns the size of the QR grid.
    int getSize();
};

// Clears the grid by filling every cell with a space.
void initializeGrid(QRCode& qr);

// Adds the three large corner patterns.
void addFinderPatterns(QRCode& qr);

// Adds the creator signature in the bottom-right corner.
void addSignature(QRCode& qr);

// Returns true if the binary fits and was encoded.
// Returns false if the message is too long for the grid.
bool encodeBinaryToGrid(QRCode& qr, const string& binary);

// Reads the QR grid and converts # and . symbols back into 1s and 0s.
string decodeGridToBinary(QRCode& qr);

#endif
