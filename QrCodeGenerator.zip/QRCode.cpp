#include "QRCode.h"
#include <iostream>

using namespace std;

QRCode::QRCode(int s) {
    size = s;

    // makes a square grid filled with spaces
    grid.resize(size, string(size, ' '));
}

vector<string>& QRCode::getGrid() {
    return grid;
}

int QRCode::getSize() {
    return size;
}

void initializeGrid(QRCode& qr) {
    vector<string>& grid = qr.getGrid();

    // clears the whole grid
    for (int r = 0; r < qr.getSize(); r++) {

        for (int c = 0; c < qr.getSize(); c++) {

            grid[r][c] = ' ';
        }
    }
}

void addFinderPatterns(QRCode& qr) {
    vector<string>& grid = qr.getGrid();

    // where the 3 corner squares start
    int positions[3][2] = {
        {0, 0},
        {0, qr.getSize() - 7},
        {qr.getSize() - 7, 0}
    };

    for (int p = 0; p < 3; p++) {

        int startR = positions[p][0];
        int startC = positions[p][1];

        // each finder pattern is 7 by 7
        for (int r = 0; r < 7; r++) {

            for (int c = 0; c < 7; c++) {

                // fill the border and middle square
                if (r == 0 || r == 6 ||
                    c == 0 || c == 6 ||
                    (r >= 2 && r <= 4 &&
                     c >= 2 && c <= 4)) {

                    grid[startR + r][startC + c] = '#';
                }

                else {

                    grid[startR + r][startC + c] = ' ';
                }
            }
        }
    }
}

void addSignature(QRCode& qr) {
    vector<string>& grid = qr.getGrid();

    // little diagonal thing in the bottom right so it has a signature
    for (int i = 0; i < 5; i++) {

        grid[qr.getSize() - 1 - i]
            [qr.getSize() - 1 - i] = '@';
    }
}

bool encodeBinaryToGrid(QRCode& qr, const string& binary) {
    vector<string>& grid = qr.getGrid();

    int capacity = 0;

    // count how many cells can store data
    // data starts at 8,8 so it doesn't mess with the corner squares
    for (int r = 8; r < qr.getSize(); r++) {

        for (int c = 8; c < qr.getSize(); c++) {

            // don't write over the signature area
            if (r >= qr.getSize() - 5 &&
                c >= qr.getSize() - 5) {

                continue;
            }

            capacity++;
        }
    }

    // don't half-save a message because that ruins the decode
    if (binary.length() > static_cast<unsigned int>(capacity)) {

        cout << "\nError: Message is too long for this QR grid." << endl;
        cout << "Binary length needed: " << binary.length() << endl;
        cout << "Grid capacity: " << capacity << endl;
        cout << "Try a shorter message or make the QR size bigger." << endl;

        return false;
    }

    int index = 0;

    for (int r = 8; r < qr.getSize(); r++) {

        for (int c = 8; c < qr.getSize(); c++) {

            // skip signature again while actually writing the data
            if (r >= qr.getSize() - 5 &&
                c >= qr.getSize() - 5) {

                continue;
            }

            if (index < static_cast<int>(binary.length())) {

                // 1 gets saved as #, 0 gets saved as .
                if (binary[index] == '1') {

                    grid[r][c] = '#';
                }

                else {

                    grid[r][c] = '.';
                }

                index++;
            }

            else {

                // blank out unused cells so random old stuff isn't there
                grid[r][c] = ' ';
            }
        }
    }

    return true;
}

string decodeGridToBinary(QRCode& qr) {
    vector<string>& grid = qr.getGrid();

    string binary = "";

    // read the exact same area the encoder wrote to
    for (int r = 8; r < qr.getSize(); r++) {

        for (int c = 8; c < qr.getSize(); c++) {

            // skip the signature area
            if (r >= qr.getSize() - 5 &&
                c >= qr.getSize() - 5) {

                continue;
            }

            // turn symbols back into bits
            if (grid[r][c] == '#') {

                binary += '1';
            }

            else if (grid[r][c] == '.') {

                binary += '0';
            }
        }
    }

    return binary;
}
