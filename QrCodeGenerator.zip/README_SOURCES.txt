Sources I used for the more confusing C++ stuff

1. <limits> / numeric_limits
   cppreference - std::numeric_limits
   https://en.cppreference.com/w/cpp/types/numeric_limits
   Basic reason I used it: numeric_limits<streamsize>::max() is basically a huge limit so cin.ignore can clear the whole input line.

2. cin.ignore
   cppreference - std::basic_istream::ignore
   https://en.cppreference.com/w/cpp/io/basic_istream/ignore
   Basic reason I used it: it throws away leftover input, like the enter key or random bad letters.

3. <fstream>, ifstream, ofstream
   cppreference - std::basic_ifstream and std::basic_ofstream
   https://en.cppreference.com/w/cpp/io/basic_ifstream
   https://en.cppreference.com/w/cpp/io/basic_ofstream
   Basic reason I used it: ifstream reads files and ofstream saves files.

4. static_cast
   cppreference - static_cast conversion
   https://en.cppreference.com/w/cpp/language/static_cast
   Basic reason I used it: it clearly changes one type into another, like char to unsigned char or size stuff.

5. substr
   cppreference - std::basic_string::substr
   https://en.cppreference.com/w/cpp/string/basic_string/substr
   Basic reason I used it: it takes part of a string, like the first 16 bits or the next 8 bits.
