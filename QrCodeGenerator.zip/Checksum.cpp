#include "Checksum.h"

int checksum(const string& text) {

    int total = 0;

    // add the number value of every character
    for (char c : text) {
        total += static_cast<unsigned char>(c);
    }

    // keep it small enough to fit in 8 bits
    return total % 256;
}
