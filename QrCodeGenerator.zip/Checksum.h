#ifndef CHECKSUM_H
#define CHECKSUM_H

#include <string>

using namespace std;

// Calculates a simple checksum for a text message.
// This is mostly used for displaying the checksum to the user.
int checksum(const string& text);

#endif
