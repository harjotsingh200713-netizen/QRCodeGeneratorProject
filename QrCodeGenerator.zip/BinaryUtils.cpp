#include "BinaryUtils.h"
#include <iostream>

using namespace std;

// turns one character into 8 bits
string charToBinary(char c) {

    // using unsigned char makes the character number stay from 0 to 255
    // Source: cppreference, static_cast conversion
    unsigned char value = static_cast<unsigned char>(c);

    string binary = "";

    // check each bit from biggest to smallest
    for (int i = 7; i >= 0; i--) {

        if ((value >> i) & 1) {
            binary += '1';
        }
        else {
            binary += '0';
        }
    }

    return binary;
}

// turns the whole message into one long binary string
string textToBinary(const string& text) {

    string binary = "";

    for (char c : text) {
        binary += charToBinary(c);
    }

    return binary;
}

// turns 8 bits back into one character
char binaryToChar(const string& bits) {

    int value = 0;

    // example: 01000001 becomes 65, which is A
    for (char bit : bits) {
        value = value * 2 + (bit - '0');
    }

    return static_cast<char>(value);
}

// turns binary back into text
string binaryToText(const string& binary) {

    string text = "";

    // every character is 8 bits, so take 8 at a time
    // Source: cppreference, std::string::substr for taking part of a string
    for (size_t i = 0; i + 7 < binary.length(); i += 8) {

        string byte = binary.substr(i, 8);

        text += binaryToChar(byte);
    }

    return text;
}

// simple checksum, just adds the character values and keeps it in 0-255
int calculateChecksum(const string& text) {

    int sum = 0;

    for (char c : text) {
        sum += static_cast<unsigned char>(c);
    }

    return sum % 256;
}

// makes a number into 8 bits, used for the checksum
string intTo8BitBinary(int value) {

    string bits = "";

    for (int i = 7; i >= 0; i--) {
        bits += ((value >> i) & 1) ? '1' : '0';
    }

    return bits;
}

// makes a number into 16 bits, used for message length
string intTo16BitBinary(int value) {

    string bits = "";

    for (int i = 15; i >= 0; i--) {
        bits += ((value >> i) & 1) ? '1' : '0';
    }

    return bits;
}

// turns binary bits into a normal int
int binaryToInt(const string& bits) {

    int value = 0;

    for (char bit : bits) {
        value = value * 2 + (bit - '0');
    }

    return value;
}

// makes the full binary for the QR
// layout: [16 bits length][message bits][8 bits checksum]
string createEncodedBinary(const string& text) {

    // length is stored first so the decoder knows where the message stops
    string lengthBits = intTo16BitBinary(static_cast<int>(text.length()));

    string textBits = textToBinary(text);

    int checksum = calculateChecksum(text);

    string checksumBits = intTo8BitBinary(checksum);

    return lengthBits + textBits + checksumBits;
}

// decodes the QR binary and checks if the checksum matches
bool decodeEncodedBinary(const string& binary, string& decodedText) {

    // need at least 16 length bits and 8 checksum bits
    if (binary.length() < 24) {
        cout << "Error: Not enough data to decode.\n";
        return false;
    }

    string lengthBits = binary.substr(0, 16);

    int textLength = binaryToInt(lengthBits);

    int textBitsLength = textLength * 8;

    int totalNeeded = 16 + textBitsLength + 8;

    // if there are not enough bits, something got cut off
    if (binary.length() < static_cast<unsigned int>(totalNeeded)) {
        cout << "Error: QR data is incomplete.\n";
        return false;
    }

    // only read the real message, not extra blank grid space
    string textBits = binary.substr(16, textBitsLength);

    // checksum comes right after the message bits
    string checksumBits = binary.substr(16 + textBitsLength, 8);

    decodedText = binaryToText(textBits);

    int originalChecksum = binaryToInt(checksumBits);

    int decodedChecksum = calculateChecksum(decodedText);

    cout << "Original checksum: " << originalChecksum << endl;
    cout << "Decoded checksum: " << decodedChecksum << endl;

    if (originalChecksum != decodedChecksum) {
        cout << "Checksum failed. Message may be corrupted.\n";
        return false;
    }

    cout << "Checksum passed.\n";

    return true;
}
